<?php
include_once '../session.php';
if (isset($_SESSION['Id'])) {
    $senderId = $_SESSION['Id'];
    $resiveId = $_POST['resiveId'];
    $IsAuto = (int) $_POST['IsAuto'];
    $output = "";
    $sql = "SELECT * FROM chating LEFT JOIN users ON users.UserId = chating.senderId
                WHERE ((senderId = {$senderId} AND resiveId = {$resiveId})
                OR (senderId = {$resiveId} AND resiveId = {$senderId}))";
    if ($IsAuto == 1) {
        $sql .= " and issee=0 and senderId<>{$senderId}";
    }
    $sql .= " ORDER BY msgid";
    $query = $db->getData($sql);
    if (mysqli_num_rows($query) > 0) {
        while ($row = mysqli_fetch_assoc($query)) {

            if ($row['senderId'] === $senderId) {
                $output .= '<div class="row">
                                <div class="col-md-6">
                                     <div class="chat-bubble chat-bubble-left">
                                          <div class="chat-bubble-tip"></div>
                                          <div class="chat-bubble-content d-flex">
                                               <img src="' . $row['img'] . '" alt="image description">
                                               <p>' . $row['msg'] . '</p>
                                          </div>
                                     </div>
                                </div>
                            </div>';
            } else {

                $output .= '<div class="row">
                                 <div class="col-md-6 offset-md-6">
                                      <div class="chat-bubble chat-bubble-right">
                                      <div class="chat-bubble-tip"></div>
                                      <div class="chat-bubble-content d-flex">
                                           <img src="' . $row['img'] . '" alt="image description">
                                           <p>' . $row['msg'] . '</p>
                                      </div>
                                      </div>
                                 </div>
                             </div>';
            }
        }
        $query = "update chating set issee=1 where resiveId=$senderId and senderId=$resiveId";
        $result = $db->update($query);
    } else {
        if ($IsAuto == 0) {
            $output .= '<div class="text">No messages are available. Once you send message they will appear here.</div>';
        }
    }
    echo $output;
}
