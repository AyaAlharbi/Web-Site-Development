const card_body= document.querySelector(".card-body");

setInterval(() =>{
    let resiveId = document.getElementById("resiveId").value;
    let IsAuto = 1;
    
    if (parseInt(resiveId)>0) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "chat/get-chat.php", true);
    xhr.onload = ()=>{
      if(xhr.readyState === XMLHttpRequest.DONE){
          if(xhr.status === 200){
            let data = xhr.response;
            if(!(data==""))
            {
                card_body.innerHTML  += data;
                scrollToBottom();
            }
          }
      }
    }
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("resiveId=" + resiveId + "&IsAuto=" + IsAuto);
    }
}, 500);

function scrollToBottom(){
    card_body.scrollTop = card_body.scrollHeight;
  }
  