<?php
include_once '../session.php';
if (isset($_SESSION['Id'])) {
    $senderId = $_SESSION['Id'];
    $resiveId =  $_POST['resiveId'];
    $message =  $_POST['message'];
    $output = '';
    if (!empty($message)) {
        $query = "insert into chating (resiveId, senderId, msg,issee)values ($resiveId, $senderId, '$message',0)";
        $result = $db->insert($query);
        if ($result) {
            $output = '<div class="row">
            <div class="col-md-6">
                 <div class="chat-bubble chat-bubble-left">
                      <div class="chat-bubble-tip"></div>
                      <div class="chat-bubble-content d-flex">
                           <img src="' . $_SESSION['img'] . '" alt="image description">
                           <p>' . $message . '</p>
                      </div>
                 </div>
            </div>
           </div>';
            echo $output;
            exit();
        } else {
            echo "error :Try other once";
        }
    } else {
        echo "error :Input message";
    }
} else
    echo "error :Please Login";
